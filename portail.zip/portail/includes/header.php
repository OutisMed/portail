<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/fonts/bootstrap-icons.css">
    <link rel="stylesheet" href="../includes/style.css">
    <title>Portail</title>
</head>
<body>

<header class=" py-3 alert-success ">
    <div class="container">
        <div class="row">
            <div class="col col-lg-6 col-md-6 d-flex flex-wrap justify-content-center">
                <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-dark text-decoration-none">
                    <svg class="bi me-2" width="40" height="32"><use xlink:href="#bootstrap"/></svg>
                    <span class="fs-4">Portail</span>
                </a>
            </div>
            <div class="col col-lg-6 col-md-6">
                <ul class="nav nav-pills">
                    <li class="nav-item"><a href="../menus/index.php" class="nav-link text-dark " aria-current="page"><i class="bi bi-house"></i> Accueil</a></li>
                    <li class="nav-item"><a href="../menus/actualite.php" class="nav-link text-dark"><i class="bi bi-newspaper"></i> Actualité</a></li>
                    <li class="nav-item"><a href="../menus/ressource.php" class="nav-link text-dark">Ressources</a></li>
                    <li class="nav-item"><a href="../menus/about.php" class="nav-link text-dark">A propos</a></li>
                </ul>
            </div>
        </div>
    </div>
</header>
    
