
<footer class="container-fluid text-dark text-center mt-4">
    <div class="row">
        <div class="w-100 col-lg-12">
            <p class="float-end mb-1">
                <a href="#"><i class="bi bi-arrow-up"></i> Haut de page</a>
            </p>
        </div>
        <div class="container-fluid col-lg-12">
            <div class="footer-in text-center">
                <p class="mb-0 w-100">&copy 2024 portail universitaire. Tous droits réservés.</p>
            </div>
        </div>

    </div>
</footer>
</body>
</html>