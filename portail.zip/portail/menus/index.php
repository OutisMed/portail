<?php require '../includes/header.php'; ?>

<div class="container-fluid alert-success" style=" border-bottom-right-radius: 30%; border-bottom-left-radius: 30%;">
    <div class="container ">
        <div class="row ">
            <div class="col col-lg-5 d-flex flex-column align-items-center justify-content-center">
                <div class="spinner-grow text-success" role="status">…
                    <span class="visually-hidden">Loading...</span>
                </div>
                <h2 class="text-primary spinner"><span class="text-success">Bienvenue</span> sur le portail 
                central des clubs de l’UDBL</h2>
                <p class="text-secondary fs-6">Votre point d'accès unique pour découvrir, participer et vous 
                impliquer dans la vie associative des Clubs</p>
                <a href="#clubs" type="button" class="btn  btn-outline-success" >Decouvrez-nous</a>
            </div>
            <div class="col col-lg-7 ">
                <img src="../assets/images/1.webp" alt="Photo" height="600">
            </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="col col-lg-12 mb-5">
            <h2 class="text-center fs-5 text-secondary mt-4">Les 4 communautés de la facultés de sciences informatique</h2>
            <div class="container">
                <div class=" d-flex flex-row  justify-content-center ">
                    <img class="m-4" src="../assets/images/logo.png" alt="" width="70">
                    <img class="m-4" src="../assets/images/Tech.jpeg" alt="" width="70">
                    <img class="m-4" src="../assets/images/flash.png" alt="" width="70">
                    <img class="m-4" src="../assets/images/logo.png" alt="" width="70">
                </div>
                
            </div>
    </div>

    <div class="content" id="clubs">
        <h3 class="text-primary text-center text-bold" ><span class="text-success">Tous les clubs</span>, une seule communauté</h3>
        <div class="container mt-4">
        <p class="text-center text-secondary">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Tempora modi 
            est quisquam dignissimos nihil, dolorem magni repudiandae hic molestias possimus,
             nisi molestiae libero? Maiores dolores aspernatur ipsum neque aperiam ea.
        </p>
        </div>
        
        <div class="row mb-5">
            <a href="../autres/page_club.php" class="col-lg-3 col-md-6 btn ">
                <div class="container g-0 p-2">
                    <div class="container d-flex justify-content-center align-items-center mt-3">
                        <div class="card card-custom border text-center">
                            <div class="circle bg-dark"></div>
                            <div class="card-body">
                                <h5 class="card-title">ESPACE ESIS</h5>
                                <p class="card-text text-secondary">Simple and secure control of your organization's 
                                financial and legal transactions. Send customized invoices and contracts</p>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
            
            <div class="col-lg-3 col-md-6 ">
                <div class="container g-0 p-2">
                    <div class="container d-flex justify-content-center align-items-center mt-3">
                        <div class="card card-custom border text-center">
                            <div class="circle bg-info"></div>
                            <div class="card-body">
                                <h5 class="card-title">TECH NET</h5>
                                <p class="card-text text-secondary">Simple and secure control of your organization's 
                                financial and legal transactions. Send customized invoices and contracts</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="container g-0 p-2">
                    <div class="container d-flex justify-content-center align-items-center mt-3">
                        <div class="card card-custom border text-center">
                            <div class="circle bg-warning"></div>
                            <div class="card-body">
                                <h5 class="card-title">INCREA</h5>
                                <p class="card-text text-secondary">Simple and secure control of your organization's 
                                financial and legal transactions. Send customized invoices and contracts</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-5">
                <div class="container g-0 p-2">
                    <div class="container d-flex justify-content-center align-items-center mt-3">
                        <div class="card card-custom border text-center">
                            <div class="circle bg-secondary"></div>
                            <div class="card-body">
                                <h5 class="card-title">FLASH</h5>
                                <p class="card-text text-secondary">Simple and secure control of your organization's 
                                financial and legal transactions. Send customized invoices and contracts</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <!-- Fin Clubs presentations-->

        <div class="container mt-4">
            <h3 class="text-primary text-center text-bold">Les Meilleurs challengers</h3>
            <p class="text-secondary text-center mb-5">Decouvrez les meilleurs challenger de nos différents clubs</p>
            <Div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="container g-0 ">
                        <div class="container d-flex justify-content-center align-items-center ">
                            <div class="bg-light shadow card p-2 card-custom border text-center d-flex flex-column align-items-center">
                                <div class=" d-flex justify-content-center align-items-center bg-dark border-2
                                    rounded-circle" style="width: 100px; height:100px">
                                        <img src="../assets/images/copie.JPG" class="rounded-circle card-img-top img-fluid" alt=""style="width: 100px; height:100px" >
                                </div>
                                <div class="card-body p-2">
                                    <h6 class="card-title text-bold text-capitalize">Mutangila Neville bilos</h6>
                                    <h5 class="card-title text-success text-uppercase">Espace Esis</h5>
                                    <p class="card-text text-secondary">A remporter les challenges vidéo explicatives 
                                        pour la pub d’un startup de la place
                                    </p>
                                    <div class="d-flex align-items-center justify-content-around">
                                        <a href=""><i class="bi bi-linkedin"></i></a>
                                        <a href=""><i class="bi bi-twitter"></i></a>
                                            
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="container g-0 ">
                        <div class="container d-flex justify-content-center align-items-center ">
                            <div class="bg-light shadow card p-2 card-custom border text-center d-flex flex-column align-items-center">
                                <div class=" d-flex justify-content-center align-items-center bg-dark border-2
                                    rounded-circle" style="width: 100px; height:100px">
                                        <img src="../assets/images/kobi.png" class="rounded-circle card-img-top img-fluid" alt=""style="width: 100px; height:100px" >
                                </div>
                                <div class="card-body p-2">
                                    <h6 class="card-title text-bold text-capitalize">Mutale joseph dido</h6>
                                    <h5 class="card-title text-success text-uppercase">Tech Net</h5>
                                    <p class="card-text text-secondary">A telecharger le plus des fichiers 
                                        build.gradle dans Android Studio. Une legende
                                    </p>
                                    <div class="d-flex align-items-center justify-content-around">
                                        <a href=""><i class="bi bi-linkedin"></i></a>
                                        <a href=""><i class="bi bi-twitter"></i></a>
                                            
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="container g-0 ">
                        <div class="container d-flex justify-content-center align-items-center ">
                            <div class="bg-light shadow card p-2 card-custom border text-center d-flex flex-column align-items-center">
                                <div class=" d-flex justify-content-center align-items-center bg-dark border-2
                                    rounded-circle" style="width: 100px; height:100px">
                                        <img src="../assets/images/mws.jpg" class="rounded-circle card-img-top img-fluid" alt=""style="width: 100px; height:100px" >
                                </div>
                                <div class="card-body p-2 h-100">
                                    <h6 class="card-title text-bold text-capitalize">Mutombo mwambi médard</h6>
                                    <h5 class="card-title text-success text-uppercase">Icrea club</h5>
                                    <p class="card-text text-secondary">Jette toujours le sachets dans la 
                                    poubelle
                                    </p>
                                    <div class="d-flex align-items-center justify-content-around">
                                        <a href=""><i class="bi bi-linkedin"></i></a>
                                        <a href=""><i class="bi bi-twitter"></i></a>
                                            
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="container g-0 ">
                        <div class="container d-flex justify-content-center align-items-center ">
                            <div class="bg-light shadow card p-2 card-custom border text-center d-flex flex-column align-items-center">
                                <div class=" d-flex justify-content-center align-items-center bg-dark border-2
                                    rounded-circle" style="width: 100px; height:100px">
                                        <img src="../assets/images/kobi.png" class="rounded-circle card-img-top img-fluid" alt=""style="width: 100px; height:100px" >
                                </div>
                                <div class="card-body p-2">
                                    <h6 class="card-title text-bold text-capitalize">Nabil mutombo mitsh.</h6>
                                    <h5 class="card-title text-success text-uppercase">Flash</h5>
                                    <p class=" card-text text-secondary">A vendu les plus de cartes sim du 
                                        resaux airtel  dans la ville de Lubumbashi
                                    </p>
                                    <div class="d-flex align-items-center justify-content-around">
                                        <a href=""><i class="bi bi-linkedin"></i></a>
                                        <a href=""><i class="bi bi-twitter"></i></a>
                                            
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </Div>
        </div>

    </div>
    
</div>

<?php require '../includes/footer.php'; ?>

