<?php require '../includes/header.php'; ?>

<main>

    <section class="py-1 text-center container">
        <div class="row py-lg-1">
            <div class="col-lg-6 col-md-8 mx-auto">
                <h1 class="fw-light">Actualités sur les Clubs</h1>
                <p class="lead text-muted">Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam dolorum sed tenetur officia alias animi sunt. Asperiores amet quos possimus tempore vero nam excepturi fugit deserunt? Ad dolores autem quasi..</p>
            </div>
        </div>
    </section>

    <div class="album py-1">
        <div class="container">

            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">

                <div class="col">
                    <div class="">
                        <div class="card w-100 h-50 ">
                            <img src="../assets/images/1.png" alt="" 
                            class="bd-placeholder-img  bd-placeholder-img-sm bd-placeholder-img-lg card-img-top "
                             height="250">
                        </div>
                        <div class="w-100 h-30  p-2">
                            <p class="">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-sm btn-success">Voir</button>
                                </div>
                                <small class="text-muted">9 mins</small>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col">
                    <div class="">
                        <div class="card w-100 h-50 ">
                            <img src="../assets/images/kobi.png" alt="" 
                            class="bd-placeholder-img  bd-placeholder-img-sm bd-placeholder-img-lg card-img-top "
                             height="250">
                        </div>
                        <div class="w-100 h-30  p-2">
                            <p class="">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-sm btn-success">Voir</button>
                                </div>
                                <small class="text-muted">9 mins</small>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col">
                    <div class="">
                        <div class="card w-100 h-50 ">
                            <img src="../assets/images/l.jpg" alt="" 
                            class="bd-placeholder-img  bd-placeholder-img-sm bd-placeholder-img-lg card-img-top "
                             height="250">
                        </div>
                        <div class="w-100 h-30  p-2">
                            <p class="">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-sm btn-success">Voir</button>
                                </div>
                                <small class="text-muted">9 mins</small>
                            </div>
                        </div>
                    </div>
                </div>

        
            </div>
        </div>
    </div>

</main>


<?php require '../includes/footer.php'; ?>