<?php require '../includes/header.php'; ?>

<section class="container mb-4">
    <div class="row">
        <div class=" col-lg-6 mt-5 ">
            <h1 class="title  bottom-2 text-uppercase fw-bolder">EspacEsis <span class="text-secondary">Club</span></h1>
            <p class="text text-secondary">
                Est une Communauté d'étudiants, passionnés du Code à l'université Don Bosco de Lubumbashi
                et d'autres personnes qui aiment le code
            </p>
            <p class="text text-secondary ">
                Lorem ipsum dolor, sit amet consectetur adipisicing elit. Odit iure praesentium, 
                voluptates qui facere cumque neque ad illum expedita, nisi provident exercitationem
                 libero quidem perferendis! Quo, tenetur. Facere, minima hic.Lorem ipsum dolor, sit amet 
                 consectetur adipisicing elit. Odit iure praesentium, 
                voluptates qui facere cumque neque ad illum expedita, nisi provident exercitationem
                 libero quidem perferendis! Quo, tenetur. Facere, minima hi
            </p>
            <a href="" class="btn btn-success shadow">Allez sur le site</a>
        </div>

        <div class="hero_img col-lg-6 d-flex border-primary align-items-center justify-content-center border-start border-2">
            <div class="">
                <a href=""><img src="../assets/images/logo.png" alt=""></a>
            </div>
            
        </div>
    </div>
</section>

    <div class="container g-0">
        <h3 class="text-primary text-center text-bold" ><span class="text-success">Evenements</span>, à Espacesis</h3>
        <div class="container mt-4">
        <p class="text-center text-secondary">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Tempora modi 
            est quisquam dignissimos nihil, dolorem magni repudiandae hic molestias possimus,
             nisi molestiae libero? Maiores dolores aspernatur ipsum neque aperiam ea.
        </p>
        <hr class="featurette-divider">

        <div class="row featurette">
            <div class="col-md-7">
                <div class="card shadow p-3">
                    <h2 class="featurette-heading">Université<span class="text-muted">à Imara un certain samedi je pense.</span></h2>
                    <p class="lead">Some great placeholder content for the Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime...</p>
                    <div class="d-flex justify-content-between align-items-center">
                    <div class="btn-group">
                        <button type="button" class="btn  btn-success">Voir plus ...</button>
                    </div>
                    <small class="text-muted"><i class="bi bi-calendar2-date">  Samedi, le 12 / 02/ 2024</i></small>
                </div>
                </div>
            </div>
            <div class="col-md-5 ">
                <div class="card p-2">
                    <img src="../assets/images/chef.jpg" alt=""class="rounded bd-placeholder-img bd-placeholder-img-lg featurette-image  mx-auto" height="250px" width="300px">
                </div>
            </div>
        </div>
      
        <hr class="featurette-divider">
    </div>



<?php require '../includes/footer.php'; ?>